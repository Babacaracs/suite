{
    "sEmptyTable":     "Aucune donnée disponible",
    "sInfo":           "Affichant _START_ à _END_ de _TOTAL_ entrées",
    "sInfoEmpty":      "Affichant 0 à 0 de 0 entrées",
    "sInfoFiltered":   "(filtré de _MAX_ entrées totales)",
    "sInfoPostFix":    "",
    "sInfoThousands":  ".",
    "sLengthMenu":     "Afficher _MENU_ entrées",
    "sLoadingRecords": "Chargement...",
    "sProcessing":     "En traitement...",
    "sSearch":         "Chercher:",
    "sZeroRecords":    "Aucun enregistrements correspondants trouvés",
    "oPaginate": {
        "sFirst":    "Premier",
        "sLast":     "Dernier",
        "sNext":     "Prochain",
        "sPrevious": "Précédent"
    },
    "oAria": {
        "sSortAscending":  ": activer pour trier la colonne en hausse",
        "sSortDescending": ": activer pour trier la colonne en descendant"
    }
}